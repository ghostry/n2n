package wang.switchy.hin2n.event;

/**
 * Created by janiszhang on 2018/4/21.
 */

public class ErrorEvent {
}
