package wang.switchy.hin2n.model;

//
// Created by switchwang(https://github.com/switch-st) on 2018-04-28.
//

public class EdgeStatus {
    public boolean isRunning;
}
